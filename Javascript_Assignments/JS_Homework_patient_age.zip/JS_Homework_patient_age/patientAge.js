const birth_year = 1978;
let current_year = new Date().getFullYear();
let age = current_year - birth_year;

console.log(`Patient's Age: ${age}`);

const width = 16;
const length = 20;
let area = width * length;

console.log(`Width: ${width}`);
console.log(`Length: ${length}`);
console.log(`Area: ${area}`);
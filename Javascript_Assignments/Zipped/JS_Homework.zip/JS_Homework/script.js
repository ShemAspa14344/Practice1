let firstName = "Shem"
let lastName = "Aspa"
const msg = `Hello!, ${firstName} ${lastName}!!! How can we help you today?`;

console.log(msg);


const store_inventory = [
    {item: "shampoo", quantity: 1, price: 3 },
    {item: "soap", quantity: 0, price: 2},
    {item: "toothpaste", quantity: 2, price: 3},
]
const new_deliveries = [
    {item: "shampoo", quantity: 5, price: 4,    inventory_index: 0 },
    {item: "soap", quantity: 10, price: 2,      inventory_index: 1 },
    {item: "toothpaste", quantity: 10, price: 3,inventory_index: 2 },
]

function processDeliveries(items_obj){
    store_inventory[items_obj.inventory_index].quantity += items_obj.quantity;
    store_inventory[items_obj.inventory_index].price = items_obj.price;

}
new_deliveries.forEach(store_inventory => {
    return processDeliveries(store_inventory)
});

console.log("Delivered items have been added in the inventory");
console.log("New inventory summary:")
console.log(store_inventory)


